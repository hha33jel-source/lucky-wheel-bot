import os, sqlite3, time, hmac, hashlib, json, random
from urllib.parse import parse_qsl
from flask import Flask, jsonify, request, send_from_directory

BOT_TOKEN = os.environ.get("BOT_TOKEN", "").strip()
ADMIN_ID = int(os.environ.get("ADMIN_ID", "0") or "0")
DB_PATH = os.environ.get("DB_PATH", "wheel.sqlite3")
DAILY_SECONDS = 24 * 60 * 60

# The multiplier is applied to a base prize of 5 virtual points.
# Apple x25 is limited to one win per player per UTC calendar day.
BASE_POINTS = 5
PRIZES = [
    {"label": "🥭 ×2 ضعف", "multiplier": 2, "points": BASE_POINTS * 2, "weight": 25},
    {"label": "🍋 ×2 ضعف", "multiplier": 2, "points": BASE_POINTS * 2, "weight": 25},
    {"label": "🍉 ×2 ضعف", "multiplier": 2, "points": BASE_POINTS * 2, "weight": 25},
    {"label": "🍇 ×6 ضعف", "multiplier": 6, "points": BASE_POINTS * 6, "weight": 10},
    {"label": "🍓 ×4 ضعف", "multiplier": 4, "points": BASE_POINTS * 4, "weight": 10},
    {"label": "🥝 ×8 ضعف", "multiplier": 8, "points": BASE_POINTS * 8, "weight": 4},
    {"label": "🍎 ×25 ضعف", "multiplier": 25, "points": BASE_POINTS * 25, "weight": 1, "apple_once_daily": True},
]

app = Flask(__name__, static_folder="static")

def connect():
    db = sqlite3.connect(DB_PATH, timeout=15)
    db.row_factory = sqlite3.Row
    return db

def init_db():
    with connect() as db:
        db.execute("""CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY, first_name TEXT DEFAULT '',
            points INTEGER NOT NULL DEFAULT 0, last_free_spin INTEGER NOT NULL DEFAULT 0,
            last_daily_reward INTEGER NOT NULL DEFAULT 0
        )""")
        # Migrate existing databases created by the first version.
        columns = {r[1] for r in db.execute("PRAGMA table_info(users)").fetchall()}
        if "last_daily_reward" not in columns:
            db.execute("ALTER TABLE users ADD COLUMN last_daily_reward INTEGER NOT NULL DEFAULT 0")
        db.execute("""CREATE TABLE IF NOT EXISTS challenge_attempts (
            user_id INTEGER NOT NULL, day_key TEXT NOT NULL, correct INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY(user_id, day_key)
        )""")
        db.execute("""CREATE TABLE IF NOT EXISTS history (
            id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
            label TEXT NOT NULL, points INTEGER NOT NULL, created_at INTEGER NOT NULL,
            source TEXT NOT NULL
        )""")
        db.execute("""CREATE TABLE IF NOT EXISTS apple_daily_wins (
            user_id INTEGER NOT NULL, day_key TEXT NOT NULL,
            PRIMARY KEY(user_id, day_key)
        )""")

def get_balance(user_id):
    with connect() as db:
        row = db.execute("SELECT points FROM users WHERE user_id=?", (user_id,)).fetchone()
        return int(row["points"]) if row else 0

def add_points(user_id, amount, source="admin"):
    now = int(time.time())
    with connect() as db:
        db.execute("INSERT OR IGNORE INTO users(user_id, points) VALUES(?, 0)", (user_id,))
        db.execute("UPDATE users SET points=points+? WHERE user_id=?", (amount, user_id))
        db.execute("INSERT INTO history(user_id,label,points,created_at,source) VALUES(?,?,?,?,?)",
                   (user_id, f"+{amount} نقطة", amount, now, source))

def validate_init_data(init_data):
    """Validate Telegram Web App initData; never trust user IDs sent by the browser alone."""
    if not BOT_TOKEN or not init_data:
        return None
    try:
        pairs = dict(parse_qsl(init_data, keep_blank_values=True))
        received_hash = pairs.pop("hash", None)
        if not received_hash:
            return None
        auth_date = int(pairs.get("auth_date", "0"))
        if auth_date <= 0 or abs(int(time.time()) - auth_date) > 86400:
            return None
        data_check_string = "\n".join(f"{k}={v}" for k, v in sorted(pairs.items()))
        secret_key = hmac.new(b"WebAppData", BOT_TOKEN.encode(), hashlib.sha256).digest()
        calculated = hmac.new(secret_key, data_check_string.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(calculated, received_hash):
            return None
        user_data = json.loads(pairs.get("user", "{}"))
        user_id = int(user_data["id"])
        first_name = str(user_data.get("first_name", ""))[:80]
        return {"id": user_id, "first_name": first_name}
    except (ValueError, KeyError, TypeError, json.JSONDecodeError):
        return None

def require_user():
    data = validate_init_data(request.headers.get("X-Telegram-Init-Data", ""))
    if not data:
        return None
    return data

@app.get("/")
def home():
    return send_from_directory("static", "index.html")

@app.get("/api/state")
def state():
    user = require_user()
    if not user:
        return jsonify({"error": "افتح اللعبة من داخل بوت تلغرام."}), 401
    now = int(time.time())
    with connect() as db:
        db.execute("INSERT OR IGNORE INTO users(user_id, first_name) VALUES(?,?)",
                   (user["id"], user["first_name"]))
        db.execute("UPDATE users SET first_name=? WHERE user_id=?",
                   (user["first_name"], user["id"]))
        row = db.execute("SELECT points,last_free_spin,last_daily_reward FROM users WHERE user_id=?",
                         (user["id"],)).fetchone()
        hist = db.execute("SELECT label,points,created_at FROM history WHERE user_id=? "
                          "ORDER BY id DESC LIMIT 10", (user["id"],)).fetchall()
    last = int(row["last_free_spin"])
    remaining = max(0, DAILY_SECONDS - (now - last)) if last else 0
    return jsonify({
        "first_name": user["first_name"], "points": int(row["points"]),
        "free_spin_available": remaining == 0, "free_spin_seconds": remaining,
        "daily_reward_available": (not row["last_daily_reward"] or now - int(row["last_daily_reward"]) >= DAILY_SECONDS),
        "challenge_available": not challenge_done(user["id"]),
        "history": [{"label": r["label"], "points": r["points"], "created_at": r["created_at"]} for r in hist],
        "prizes": [{"label": p["label"], "points": p["points"]} for p in PRIZES]
    })

def perform_spin(user_id, source):
    now = int(time.time())
    with connect() as db:
        db.execute("BEGIN IMMEDIATE")
        db.execute("INSERT OR IGNORE INTO users(user_id, points, last_free_spin) VALUES(?,0,0)", (user_id,))
        row = db.execute("SELECT points,last_free_spin FROM users WHERE user_id=?", (user_id,)).fetchone()
        if source == "free":
            if row["last_free_spin"] and now - int(row["last_free_spin"]) < DAILY_SECONDS:
                db.rollback()
                return None, "استخدمت محاولتك المجانية. حاول مجددًا بعد انتهاء المؤقت."
            db.execute("UPDATE users SET last_free_spin=? WHERE user_id=?", (now, user_id))
        else:
            db.rollback()
            return None, "التدوير المجاني فقط متاح في هذه اللعبة."
        today = day_key()
        already_won_apple = db.execute(
            "SELECT 1 FROM apple_daily_wins WHERE user_id=? AND day_key=?", (user_id, today)
        ).fetchone() is not None
        eligible_prizes = [p for p in PRIZES if not (p.get("apple_once_daily") and already_won_apple)]
        prize = random.choices(eligible_prizes, weights=[p["weight"] for p in eligible_prizes], k=1)[0]
        if prize.get("apple_once_daily"):
            db.execute("INSERT INTO apple_daily_wins(user_id, day_key) VALUES(?,?)", (user_id, today))
        db.execute("UPDATE users SET points=points+? WHERE user_id=?", (prize["points"], user_id))
        db.execute("INSERT INTO history(user_id,label,points,created_at,source) VALUES(?,?,?,?,?)",
                   (user_id, prize["label"], prize["points"], now, source))
        balance = db.execute("SELECT points FROM users WHERE user_id=?", (user_id,)).fetchone()["points"]
        db.commit()
    return {"label": prize["label"], "multiplier": prize["multiplier"],
            "points": prize["points"], "balance": balance,
            "prize_index": PRIZES.index(prize)}, None

@app.post("/api/spin")
def spin():
    user = require_user()
    if not user:
        return jsonify({"error": "تعذر التحقق من حساب تلغرام. افتح البوت ثم اضغط زر العجلة."}), 401
    body = request.get_json(silent=True) or {}
    result, error = perform_spin(user["id"], "free")
    if error:
        return jsonify({"error": error}), 400
    return jsonify(result)

CHALLENGES = [
    {"question": "ما عاصمة الجزائر؟", "choices": ["وهران", "الجزائر العاصمة", "قسنطينة", "تقرت"], "answer": 1},
    {"question": "كم يساوي 7 × 6؟", "choices": ["36", "40", "42", "48"], "answer": 2},
    {"question": "أي كوكب يُعرف بالكوكب الأحمر؟", "choices": ["الزهرة", "المريخ", "المشتري", "عطارد"], "answer": 1},
    {"question": "كم عدد أيام الأسبوع؟", "choices": ["5", "6", "7", "8"], "answer": 2},
    {"question": "أي حيوان يُعرف بأنه ملك الغابة؟", "choices": ["الفيل", "الأسد", "الحصان", "الدب"], "answer": 1},
]

def day_key():
    # UTC day key: one challenge attempt per user per UTC day.
    return time.strftime("%Y-%m-%d", time.gmtime())

def challenge_done(user_id):
    with connect() as db:
        return db.execute("SELECT 1 FROM challenge_attempts WHERE user_id=? AND day_key=?",
                          (user_id, day_key())).fetchone() is not None

def challenge_for_user(user_id):
    index = (int(user_id) + int(day_key().replace("-", ""))) % len(CHALLENGES)
    return CHALLENGES[index]

@app.post("/api/daily-reward")
def daily_reward():
    user = require_user()
    if not user:
        return jsonify({"error": "افتح اللعبة من داخل بوت تلغرام."}), 401
    now = int(time.time())
    with connect() as db:
        db.execute("BEGIN IMMEDIATE")
        db.execute("INSERT OR IGNORE INTO users(user_id, first_name) VALUES(?,?)", (user["id"], user["first_name"]))
        row = db.execute("SELECT last_daily_reward,points FROM users WHERE user_id=?", (user["id"],)).fetchone()
        if row["last_daily_reward"] and now - int(row["last_daily_reward"]) < DAILY_SECONDS:
            db.rollback()
            return jsonify({"error": "استلمت مكافأتك اليومية بالفعل. عد غدًا!"}), 400
        amount = 5
        db.execute("UPDATE users SET last_daily_reward=?, points=points+? WHERE user_id=?", (now, amount, user["id"]))
        db.execute("INSERT INTO history(user_id,label,points,created_at,source) VALUES(?,?,?,?,?)",
                   (user["id"], "مكافأة يومية", amount, now, "daily"))
        balance = int(row["points"]) + amount
        db.commit()
    return jsonify({"message": "🎁 حصلت على 5 نقاط كمكافأة يومية!", "points": amount, "balance": balance})

@app.get("/api/challenge")
def get_challenge():
    user = require_user()
    if not user:
        return jsonify({"error": "افتح اللعبة من داخل بوت تلغرام."}), 401
    if challenge_done(user["id"]):
        return jsonify({"available": False, "message": "أكملت تحدي اليوم. عد غدًا!"})
    q = challenge_for_user(user["id"])
    return jsonify({"available": True, "question": q["question"], "choices": q["choices"]})

@app.post("/api/challenge")
def answer_challenge():
    user = require_user()
    if not user:
        return jsonify({"error": "افتح اللعبة من داخل بوت تلغرام."}), 401
    body = request.get_json(silent=True) or {}
    try:
        choice = int(body.get("choice", -1))
    except (TypeError, ValueError):
        choice = -1
    q = challenge_for_user(user["id"])
    now = int(time.time())
    with connect() as db:
        db.execute("BEGIN IMMEDIATE")
        db.execute("INSERT OR IGNORE INTO users(user_id, first_name) VALUES(?,?)", (user["id"], user["first_name"]))
        try:
            db.execute("INSERT INTO challenge_attempts(user_id,day_key,correct) VALUES(?,?,0)", (user["id"], day_key()))
        except sqlite3.IntegrityError:
            db.rollback()
            return jsonify({"error": "أكملت تحدي اليوم بالفعل. عد غدًا!"}), 400
        if choice == q["answer"]:
            amount, message = 10, "إجابة صحيحة! ربحت 10 نقاط 🎉"
            db.execute("UPDATE challenge_attempts SET correct=1 WHERE user_id=? AND day_key=?", (user["id"], day_key()))
            db.execute("UPDATE users SET points=points+? WHERE user_id=?", (amount, user["id"]))
            db.execute("INSERT INTO history(user_id,label,points,created_at,source) VALUES(?,?,?,?,?)",
                       (user["id"], "تحدي يومي: إجابة صحيحة", amount, now, "challenge"))
        else:
            amount, message = 0, "ليست الإجابة الصحيحة. يمكنك المحاولة مجددًا غدًا."
            db.execute("INSERT INTO history(user_id,label,points,created_at,source) VALUES(?,?,?,?,?)",
                       (user["id"], "تحدي يومي: إجابة غير صحيحة", 0, now, "challenge"))
        balance = db.execute("SELECT points FROM users WHERE user_id=?", (user["id"],)).fetchone()["points"]
        db.commit()
    return jsonify({"message": message, "points": amount, "balance": int(balance), "correct": choice == q["answer"]})

@app.get("/health")
def health():
    return jsonify({"ok": True})

if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "8080")))
